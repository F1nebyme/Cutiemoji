// 颜文字数据库
const kaomojiData = {
    happy: {
        name: '开心',
        items: [
            '(｡♥‿♥｡)',
            '(◕‿◕)',
            '(｡◕‿◕｡)',
            'ヽ(◕‿◕)ノ',
            '(✿◠‿◠)',
            '٩(◕‿◕)۶',
            '(◠‿◠)',
            '☆(◒‿◒)☆',
            '(｡◕‿◕｡)♡',
            '✧(◕‿◕)✧',
            '(ﾉ◕ヮ◕)ﾉ*:･ﾟ✧',
            '♪(┌・。・)┌',
            '(^_^)',
            '(^o^)',
            '(^▽^)',
            '(＾▽＾)',
            'o(〃＾▽＾〃)o',
            '(*^▽^*)',
            '(｡･ω･｡)',
            '(´｡• ᵕ •｡`)'
        ]
    },
    cute: {
        name: '可爱',
        items: [
            '(◕ᴥ◕)',
            '(◠ᴥ◠)',
            '(✿╹◡╹)',
            '(◍•ᴗ•◍)',
            '(｡･ω･｡)ﾉ♡',
            '(*´ω`*)',
            '(´∩｡• ᵕ •｡∩`)',
            '⊂(´･◡･⊂ )∘˚˳°',
            '(｡･ω･｡)',
            '(◍•ᴗ•◍)❤',
            '(｡♥‿♥｡)',
            '(◕‿◕✿)',
            '(｡◕‿◕｡)✿',
            '(◠‿◠✿)',
            '(◡‿◡✿)',
            '✿◕ ‿ ◕✿',
            '(◕‿◕)♡',
            '(｡♥‿♥｡)',
            '(◍•ᴗ•◍)♡',
            '(*^‿^*)'
        ]
    },
    sad: {
        name: '伤心',
        items: [
            '(╥﹏╥)',
            '(╥_╥)',
            '(╯︵╰,)',
            '(｡•́︿•̀｡)',
            '(｡╯︵╰｡)',
            '(╥﹏╥)',
            '(╯_╰)',
            '(｡•́︿•̀｡)',
            '(｡•́︿•̀｡)♡',
            '(╥_╥)',
            '(｡•́︿•̀｡)',
            '(╯︵╰,)',
            '(｡•́︿•̀｡)',
            '(╥﹏╥)',
            '(｡•́︿•̀｡)',
            '(╯_╰)',
            '(｡•́︿•̀｡)',
            '(╥﹏╥)',
            '(｡•́︿•̀｡)',
            '(╯︵╰,)'
        ]
    },
    angry: {
        name: '生气',
        items: [
            '(╬ Ò﹏Ó)',
            '(╬ಠ益ಠ)',
            '(ಠ_ಠ)',
            '(╬ Ò﹏Ó)',
            '(¬_¬)',
            '(╬ Ò﹏Ó)',
            '(ಠ_ಠ)',
            '(¬_¬)',
            '(╬ Ò﹏Ó)',
            '(ಠ_ಠ)',
            '(¬_¬)',
            '(╬ Ò﹏Ó)',
            '(ಠ_ಠ)',
            '(¬_¬)',
            '(╬ Ò﹏Ó)',
            '(ಠ_ಠ)',
            '(¬_¬)',
            '(╬ Ò﹏Ó)',
            '(ಠ_ಠ)',
            '(¬_¬)'
        ]
    },
    surprised: {
        name: '惊讶',
        items: [
            '(⊙_⊙)',
            '(⊙_☉)',
            '(◎_◎;)',
            '(⊙_⊙)',
            '(◎_◎;)',
            '(⊙_☉)',
            '(⊙_⊙)',
            '(◎_◎;)',
            '(⊙_☉)',
            '(⊙_⊙)',
            '(◎_◎;)',
            '(⊙_☉)',
            '(⊙_⊙)',
            '(◎_◎;)',
            '(⊙_☉)',
            '(⊙_⊙)',
            '(◎_◎;)',
            '(⊙_☉)',
            '(⊙_⊙)',
            '(◎_◎;)'
        ]
    },
    love: {
        name: '喜欢',
        items: [
            '(♡°▽°♡)',
            '(♡˙︶˙♡)',
            '(♡˙︶˙♡)',
            '(♡°▽°♡)',
            '(♡˙︶˙♡)',
            '(♡°▽°♡)',
            '(♡˙︶˙♡)',
            '(♡°▽°♡)',
            '(♡˙︶˙♡)',
            '(♡°▽°♡)',
            '(♡˙︶˙♡)',
            '(♡°▽°♡)',
            '(♡˙︶˙♡)',
            '(♡°▽°♡)',
            '(♡˙︶˙♡)',
            '(♡°▽°♡)',
            '(♡˙︶˙♡)',
            '(♡°▽°♡)',
            '(♡˙︶˙♡)',
            '(♡°▽°♡)'
        ]
    },
    mini: {
        name: 'mini',
        items: [
            '◕‿◕',
            '◠‿◠',
            '◕ᴥ◕',
            '◠ᴥ◠',
            '⊙‿⊙',
            '⊙ᴥ⊙',
            '◕‿✿',
            '✿‿✿',
            '♡‿♡',
            '❤‿❤',
            '◔‿◔',
            '◑‿◑',
            '◕ω◕',
            '◠ω◠',
            '◕∀◕',
            '◠∀◠',
            '◕ᴗ◕',
            '◠ᴗ◠',
            '◕‿◕✿',
            '◠‿◠✿'
        ]
    },
    bling: {
        name: 'bling',
        items: [
            '✧◕‿◕✧',
            '★◕‿◕★',
            '☆◕‿◕☆',
            '✿◕‿◕✿',
            '❀◕‿◕❀',
            '✧◠‿◠✧',
            '★◠‿◠★',
            '☆◠‿◠☆',
            '✿◠‿◠✿',
            '❀◠‿◠❀',
            '✧♡‿♡✧',
            '★♡‿♡★',
            '☆♡‿♡☆',
            '✿♡‿♡✿',
            '❀♡‿♡❀',
            '✧◕ᴥ◕✧',
            '★◕ᴥ◕★',
            '☆◕ᴥ◕☆',
            '✿◕ᴥ◕✿',
            '❀◕ᴥ◕❀'
        ]
    },
    star: {
        name: '★',
        items: [
            '★~★',
            '☆~☆',
            '★彡',
            '☆彡',
            '★。☆。★',
            '☆。★。☆',
            '★*°☆',
            '☆*°★',
            '✧★✧',
            '✦★✦',
            '★⌒★',
            '☆⌒☆',
            '★(◕‿◕)★',
            '☆(◕‿◕)☆',
            '★(◠‿◠)★',
            '☆(◠‿◠)☆',
            '★~(◕‿◕~)★',
            '☆~(◠‿◠~)☆',
            '★･゜ﾟ･★',
            '☆･゜ﾟ･☆'
        ]
    },
    custom: {
        name: '自定义',
        items: []
    }
};

// 自定义颜文字存储（使用 localStorage）
const customKaomojiKey = 'kaomoji-custom-data';
const importedKaomojiKey = 'kaomoji-imported-data';

// 加载自定义颜文字
function loadCustomKaomoji() {
    const saved = localStorage.getItem(customKaomojiKey);
    if (saved) {
        try {
            const custom = JSON.parse(saved);
            kaomojiData.custom.items = custom.items || [];
        } catch (e) {
            console.error('加载自定义颜文字失败:', e);
        }
    }
}

// 加载导入到其他分类的颜文字
function loadImportedKaomoji() {
    const saved = localStorage.getItem(importedKaomojiKey);
    if (saved) {
        try {
            const imported = JSON.parse(saved);
            for (const category in imported) {
                if (kaomojiData[category]) {
                    imported[category].forEach(text => {
                        if (!kaomojiData[category].items.includes(text)) {
                            kaomojiData[category].items.push(text);
                        }
                    });
                }
            }
        } catch (e) {
            console.error('加载导入颜文字失败:', e);
        }
    }
}

// 保存自定义颜文字
function saveCustomKaomoji() {
    localStorage.setItem(customKaomojiKey, JSON.stringify({
        items: kaomojiData.custom.items
    }));
}

// 保存导入到其他分类的颜文字
function saveImportedKaomoji(category) {
    const saved = JSON.parse(localStorage.getItem(importedKaomojiKey) || '{}');
    saved[category] = kaomojiData[category].items;
    localStorage.setItem(importedKaomojiKey, JSON.stringify(saved));
}

// 添加自定义颜文字
function addCustomKaomoji(text, category = 'custom') {
    if (!text || text.trim() === '') return false;
    text = text.trim();

    if (kaomojiData[category]) {
        if (!kaomojiData[category].items.includes(text)) {
            kaomojiData[category].items.push(text);
            if (category === 'custom') {
                saveCustomKaomoji();
            } else {
                saveImportedKaomoji(category);
            }
            return true;
        }
    }
    return false;
}

// 批量导入颜文字
function importKaomojiList(list, category = 'custom') {
    let added = 0;
    list.forEach(text => {
        if (addCustomKaomoji(text, category)) {
            added++;
        }
    });
    return added;
}

// 导出所有颜文字
function exportAllKaomoji() {
    return {
        ...kaomojiData,
        exportDate: new Date().toISOString(),
        version: '1.0'
    };
}

// 从 JSON 导入
function importFromJSON(jsonData) {
    try {
        const data = typeof jsonData === 'string' ? JSON.parse(jsonData) : jsonData;
        let totalAdded = 0;

        for (const category in data) {
            if (category === 'exportDate' || category === 'version') continue;

            if (kaomojiData[category] && data[category].items) {
                const added = importKaomojiList(data[category].items, category);
                totalAdded += added;
            } else if (data[category].items) {
                // 新分类，添加到自定义
                const added = importKaomojiList(data[category].items, 'custom');
                totalAdded += added;
            }
        }
        return { success: true, added: totalAdded };
    } catch (e) {
        return { success: false, error: e.message };
    }
}

// 初始化时加载自定义颜文字
loadCustomKaomoji();
loadImportedKaomoji();

// 获取所有颜文字
function getAllKaomoji() {
    const all = [];
    for (const category in kaomojiData) {
        kaomojiData[category].items.forEach(item => {
            all.push({
                text: item,
                category: category,
                categoryName: kaomojiData[category].name
            });
        });
    }
    return all;
}

// 根据分类获取颜文字
function getKaomojiByCategory(category) {
    if (category === 'all') {
        return getAllKaomoji();
    }
    if (kaomojiData[category]) {
        return kaomojiData[category].items.map(item => ({
            text: item,
            category: category,
            categoryName: kaomojiData[category].name
        }));
    }
    return [];
}

// 搜索颜文字
function searchKaomoji(query) {
    const all = getAllKaomoji();
    if (!query) return all;
    return all.filter(k => k.text.toLowerCase().includes(query.toLowerCase()));
}
